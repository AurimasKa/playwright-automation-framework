export const shippingData = {
  shipping: {
    firstName: 'Testas',
    lastName: 'Testauskas',
    streetAddress: '109 Bentmoor Cir',
    addressLine2: '',
    city: 'Helena',
    state: 'AL',
    zipCode: '35080-7082',
    email: 'testas.testauskas@gmail.com',
    phoneNumber: '0942309253',
  },
};

