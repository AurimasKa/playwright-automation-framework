export const API_BASE_URL = 'https://petstore.swagger.io/v2';

