export function deleteOrderPayload(orderId: number) {
  return {
    orderId,
  };
}

